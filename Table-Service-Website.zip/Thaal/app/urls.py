from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('dish/', views.dish, name='dish'),
    path('order/', views.order, name='order_dish'),  # Path for order view
    path('confirm/', views.confirm, name='confirm_order'),  # Path for confirm view
    path('delete/', views.deleted, name='delete_order'),
    path('bill/', views.bill, name='bill'),
    path('table/<str:table_number>',views.prints, name='print'),
]
