from django.shortcuts import render, redirect
from .models import Order

from django.shortcuts import render
from .models import Order

def index(request):
    occupied_tables = Order.objects.values_list('table_number', flat=True).distinct()
    context = {
        'occupied_tables': occupied_tables,
        'range': [str(i) for i in range(1, 10)],  # Pass the range as strings to the template
    }
    return render(request, 'index.html', context)

def dish(request):
    table_number = request.GET.get('table')
    table = {'table_number': table_number}
    
    # Retrieve order items from the session
    order_items = request.session.get('order_items', [])
    
    # Add order items to the context
    context = {
        'table_number': table_number,
        'order_items': order_items
    }
    
    return render(request, 'dish.html', context)

def order(request):
    if request.method == 'POST':
        name = request.POST.get('curry_name')
        price = int(request.POST.get('price'))
        quantity = int(request.POST.get('quantity'))
        table_number = request.POST.get('table_number')

        # Calculate total price
        total_price = price * quantity

        # Prepare items dictionary
        item = {
            'name': name,
            'quantity': quantity,
            'price': price,
            'total_price': total_price
        }

        # Retrieve the current order items from the session
        order_items = request.session.get('order_items', [])
        
        # Add the new item to the order items
        order_items.append(item)
        
        # Save the updated order items in the session
        request.session['order_items'] = order_items

        # Redirect back to the dish view with the table number
        redirect_url = f'/dish?table={table_number}'
        return redirect(redirect_url)
    
    return redirect('index')

def confirm(request):
    if request.method == 'GET':
        # Retrieve order items from the session
        order_items = request.session.get('order_items', [])
        table_number = request.GET.get('table_number')  # Get table number if it's part of the request

        if order_items:
            # Save each order item to the database
            for item in order_items:
                Order.objects.create(
                    table_number=table_number,
                    name=item['name'],
                    quantity=item['quantity'],
                    price=item['price'],
                    total_price=item['total_price']
                    
                )
            
            # Clear the order items from the session
            request.session.pop('order_items', None)
        
        # Redirect to the home page or a confirmation page
        return redirect('index')

def deleted(request):
    if request.method == 'POST':

        item_name = request.POST.get('item_name')
        
        # Retrieve order items from the session
        order_items = request.session.get('order_items', [])
        
        # Remove the item with the specified name
        order_items = [item for item in order_items if item['name'] != item_name]
        
        # Save the updated order items in the session
        request.session['order_items'] = order_items
    
    # Redirect back to the dish view
    return redirect(request.META.get('HTTP_REFERER', '/'))
   
def bill(request):
    if request.method == 'GET':
        table_number = request.GET.get('table')
        if table_number:
            # Filter orders based on table_number
            bills = Order.objects.filter(table_number=table_number)
            total_amount = sum(bill.total_price for bill in bills)
            
            # Pass the bills to a template for rendering
            context = {
                'table_number': table_number,
                'bills': bills,
                'total_amount': total_amount
            }
            print(context)
            return render(request, 'bill.html', context)
        else:
            # If no table_number is provided, redirect to the index page
            return redirect('index')



def prints(request,table_number):

    if request.method == 'GET':
        Order.objects.filter(table_number=table_number).delete()
        
        # Redirect to a page after printing and deleting
        return redirect('index')
        



